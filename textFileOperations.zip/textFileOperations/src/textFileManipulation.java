import java.io.IOException;

public class textFileManipulation {

    public static void main(String[] args) throws IOException {
        KeyboardInput.setInput();
        //First, by the class GetValidFile we check if the name of the file and its content is valid
        GetValidFile validFile = new GetValidFile();
        boolean execute = validFile.getFileName();
        if (execute == false) {
            return;
        }
        String inputFile = validFile.getInputFile();
        //Second, by the class TextFileLinesList we split the file into lines and saved in a local ArrayList,
        // then the lines into strings and separators in two Sting arrays;
        // TextFileLinesList provides all the necessary functionalities for the 3.b and 3.c Swtich manipulations
        // and the CRUD operations
        TextFileLinesList textFile = new TextFileLinesList();
        textFile.splitFileLines(validFile.getFileLines());
        int option = 0;
        do {
            System.out.println("\nText file manipulation:");
            System.out.println("1. Switch one line with another");
            System.out.println("2. Switch one number with another");
            System.out.println("3. Read number in the file");
            System.out.println("4. Insert number in the file");
            System.out.println("5. Modify number in the file");
            System.out.println("6. Remove number from the file");
            System.out.println("7. Exit");
            System.out.println("\nPlease, choose an option to continue: ");

            try {
                option = KeyboardInput.getInput().nextInt();
            } catch (NumberFormatException nfe) {
                System.out.println("\nOption is a number between 1 and 7!!!");
            }

            switch (option) {
                case 1:
                    textFile.switchLines();
                    break;
                case 2:
                    textFile.switchNumbers();
                    break;
                case 3:
                    textFile.readNumber();
                    break;
                case 4:
                    textFile.insertNumber();
                    break;
                case 5:
                    textFile.modifyNumber();
                    break;
                case 6:
                    textFile.removeNumber();
                    break;
                case 7:
                    System.out.println("Exit...");
                    break;
                default:
                    System.out.println("Invalid option number!");
                    break;
            }
        } while (option != 7);

        KeyboardInput.closeScanner();
        //After successful validation and completion of required operations over the passed filename,
        //it is overwritten
        textFile.saveToFile(inputFile);
    }
}