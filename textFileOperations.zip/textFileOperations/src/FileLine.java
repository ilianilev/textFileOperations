import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileLine {
    private List<NumberAndSeparator> fileLines;

    public FileLine() {
        this.fileLines = new ArrayList<NumberAndSeparator>();
    }

    public List<NumberAndSeparator> getFileLines() {
        return fileLines;
    }

    public NumberAndSeparator getLine(int index) {
        return fileLines.get(index);
    }

    public void setFileLines(NumberAndSeparator numSep) {
        fileLines.add(numSep);
    }

    public void insertNumber(int indexLine) throws IOException {
        NumberAndSeparator previousElem;
        System.out.format("\nPlease, enter number index: ");
        int indexNumber = KeyboardInput.inputIndex(fileLines.size() + 1);
        if(indexNumber != 0)
        {
            previousElem = fileLines.get(indexNumber-1);
            previousElem.setSeparator(" ");
        }
        String numberToInsert = KeyboardInput.inputNumber();
        String separator;
        if (indexNumber != fileLines.size() - 1) {
            separator = " ";
        } else {
            separator = "";
        }
        NumberAndSeparator numSep = new NumberAndSeparator(numberToInsert, separator);
        fileLines.add(indexNumber, numSep);
        System.out.format("Number %s inserted at index %d on line %d \n", numberToInsert, indexNumber + 1,
                indexLine + 1);
    }

    public void removeNumber(int indexLine) throws IOException {
        System.out.format("\nPlease, enter number index: ");
        int indexNumber = KeyboardInput.inputIndex(fileLines.size());
        String removedNumber = fileLines.remove(indexNumber).getNumber();
        System.out.format("On line %d the number %s with index %d was removed\n", indexLine + 1, removedNumber,
                indexNumber + 1);
    }

    public void modifyNumber(int indexLine, String valueModify) throws IOException {
        System.out.format("\nPlease, enter number index: ");
        int indexNumber = KeyboardInput.inputIndex(fileLines.size());
        NumberAndSeparator numSep = fileLines.get(indexNumber);
        System.out.format("On line %d at index %d the number %s was modified\n", indexLine + 1, indexNumber + 1,
                numSep.getNumber());
        numSep.setNumber(valueModify);
    }

    public int getListSize() {
        return fileLines.size();
    }

}
