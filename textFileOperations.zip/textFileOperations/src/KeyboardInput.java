import java.io.IOException;
import java.util.Scanner;

public class KeyboardInput {
    private static Scanner input;

    public static void setInput() {
        input = new Scanner(System.in);
    }

    public static Scanner getInput()
    {
        return input;
    }

    public static int inputIndex(int maxValue) throws IOException {
        int index = 0;
        boolean isDigit = false;

        while (!isDigit) {
            try {
                index = input.nextInt();
                index = index - 1;
                isDigit = true;
            } catch (NumberFormatException nfe) {
                System.out.println("\nLine index should be a digit!!!");
            }
        }
        if (index < 0 || index >= maxValue) {
            throw new IllegalArgumentException("Wrong index!");
        }
        return index;
    }

    public static String inputNumber() throws IOException {
        int enteredNumber = 0;
        String inputNum = null;
        boolean isDigit = false;
        while (!isDigit) {
            System.out.println("\nPlease, enter number: ");
            try {
                enteredNumber = input.nextInt();
                isDigit = true;
            } catch (NumberFormatException nfe) {
                System.out.println("\nNumber should contain digits!!!");
                continue;
            }
        }
        inputNum = Integer.toString(enteredNumber);
        return inputNum;
    }

    public static void closeScanner()
    {
        input.close();
    }

}
