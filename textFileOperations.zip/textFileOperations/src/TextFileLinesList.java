import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TextFileLinesList {
    private ArrayList<FileLine> textFileLines;
    boolean fileModified = false;

    private static final Pattern pattern = Pattern.compile("\\s+");

    public TextFileLinesList() {
        textFileLines = new ArrayList<FileLine>();
    }

    public void splitFileLines(ArrayList<String> fileLines) {
        int k = 0;
        String[] lineParts;
        String[] lineSeparators;

        Matcher matcher;
        for (int i = 0; i < fileLines.size(); i++) {
            matcher = pattern.matcher(fileLines.get(i));

            lineParts = fileLines.get(i).split("\\s+");

            lineSeparators = new String[lineParts.length];

            while (matcher.find()) {
                // lineSeparators[i] = matcher.group(0);
                lineSeparators[k] = fileLines.get(i).substring(matcher.start(), matcher.start() + 1);
                k++;
            }

            FileLine fLine = new FileLine();

            for (int j = 0; j < lineParts.length; j++) {

                NumberAndSeparator numSep;

                if(j == lineParts.length - 1)
                {
                    numSep = new NumberAndSeparator(lineParts[j], "");
                }
                else
                {
                    numSep = new NumberAndSeparator(lineParts[j], lineSeparators[j]);
                }

                fLine.setFileLines(numSep);
            }

            k = 0;
            textFileLines.add(fLine);
        }
    }

    public boolean switchLines() throws IOException {
        fileModified = true;
        System.out.format("\nPlease, enter index of first line: ");
        int firstLineIndex = KeyboardInput.inputIndex(textFileLines.size());

        System.out.format("\nPlease, enter index of second line: ");
        int secondLineIndex = KeyboardInput.inputIndex(textFileLines.size());

        FileLine firstFileLine = textFileLines.get(firstLineIndex);
        FileLine secondFileLine = textFileLines.get(secondLineIndex);

        textFileLines.set(firstLineIndex, secondFileLine);
        textFileLines.set(secondLineIndex, firstFileLine);

        return true;
    }

    public void switchNumbers() throws IOException {
        fileModified = true;
        System.out.println("\nEnter line index and number index for first number:");
        System.out.print("Line index: ");
        int indexLine1 = KeyboardInput.inputIndex(textFileLines.size());
        System.out.print("Number index: ");
        int indexNumber1 = KeyboardInput.inputIndex(textFileLines.get(indexLine1).getFileLines().size());

        System.out.println("\nEnter line index and number index for second number:");
        System.out.print("Line index: ");
        int indexLine2 = KeyboardInput.inputIndex(textFileLines.size());
        System.out.print("\nNumber index: ");
        int indexNumber2 = KeyboardInput.inputIndex(textFileLines.get(indexLine2).getFileLines().size());

        FileLine firstFileLine = textFileLines.get(indexLine1);
        NumberAndSeparator firstPart = firstFileLine.getLine(indexNumber1);
        String firstNumber = firstPart.getNumber();

        FileLine secondFileLine = textFileLines.get(indexLine2);
        NumberAndSeparator secondPart = secondFileLine.getLine(indexNumber2);
        String secondNumber = secondPart.getNumber();

        firstPart.setNumber(secondNumber);
        secondPart.setNumber(firstNumber);
    }

    public void readNumber() throws IOException {
        System.out.format("\nPlease, enter index of line: ");
        int indexLine = KeyboardInput.inputIndex(textFileLines.size());

        System.out.format("\nPlease, enter index of number: ");
        FileLine fileLine = textFileLines.get(indexLine);
        int indexNumber = KeyboardInput.inputIndex(fileLine.getFileLines().size());

        System.out.format("On line %d at index %d the number is %s\n", indexLine + 1, indexNumber + 1,
                fileLine.getLine(indexNumber).getNumber());
    }

    public void insertNumber() throws IOException {
        fileModified = true;
        int indexLine = 0;
        System.out.print("Enter the position for insert: ");
        System.out.format("\nPlease, enter line index: ");
        indexLine = KeyboardInput.inputIndex(textFileLines.size());

        FileLine fileLine = textFileLines.get(indexLine);
        fileLine.insertNumber(indexLine);
    }

    public void modifyNumber() throws IOException {
        fileModified = true;
        String valueModify = KeyboardInput.inputNumber();
        System.out.println("Enter the position for modification: ");
        System.out.format("\nPlease, enter line index: ");
        int indexLine = KeyboardInput.inputIndex(textFileLines.size());
        FileLine fileLine = textFileLines.get(indexLine);
        fileLine.modifyNumber(indexLine, valueModify);
    }

    public void removeNumber() throws IOException {
        fileModified = true;
        System.out.print("Enter the position for remove: ");
        System.out.format("\nPlease, enter line index: ");
        int indexLine = KeyboardInput.inputIndex(textFileLines.size());
        FileLine fileLine = textFileLines.get(indexLine);
        fileLine.removeNumber(indexLine);
    }

    public ArrayList<FileLine> getTextFileLines() {
        return textFileLines;
    }

    public void saveToFile(String fileName) {
        if (!fileModified) {
            return;
        }
        try (PrintStream ps = new PrintStream(fileName)) {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < textFileLines.size(); i++) {
                builder.setLength(0);
                FileLine fileLine = textFileLines.get(i);
                for (int j = 0; j < fileLine.getListSize(); j++) {
                    NumberAndSeparator numSep = fileLine.getLine(j);
                    builder.append(numSep.getNumber()).append(numSep.getSeparator());
                }

                if (i != textFileLines.size() - 1) {
                    builder.append(System.lineSeparator());
                }
                ps.print(builder.toString());
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        System.out.format("File %s modified successfully!", fileName);
    }
}
