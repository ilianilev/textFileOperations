import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GetValidFile {
    private static final Pattern fileNamePattern = Pattern.compile("[^\\\\/:*?\"<>|]+[.][a-zA-Z]+$");
    private static final Pattern fileContentPattern = Pattern.compile("[0-9\\s\\t]*");

    private ArrayList<String> fileLines;
    private String inputFile;

    public boolean getFileName() {
        boolean result = true;

        do {
            System.out.println("\nPlease, enter the path to the file or enter \"exit\": ");
            inputFile = KeyboardInput.getInput().nextLine().trim();
            if (inputFile.toLowerCase().equals("exit")) {
                result = false;
                System.out.println("Exit...");
                break;
            }
        } while (!isFileNameValid(inputFile));
        return result;
    }

    private boolean isFileNameValid(String filePath) {
        String fileName = filePath.substring(filePath.lastIndexOf("\\") + 1);
        Matcher m = fileNamePattern.matcher(fileName);
        boolean isMatching = m.matches();

        if (isMatching == true && fileName.endsWith(".txt")) {
            if (isFileContentValid(filePath)) {
                return true;
            } else {
                return false;
            }
        } else {
            System.out.println("Invalid file name!");
            return false;
        }
    }

    private boolean isFileContentValid(String fileName) {
        fileLines = new ArrayList<>();
        int lineNumber = 0;

        try (Scanner fileReader = new Scanner(new File(fileName))) {
            System.out.println("File " + fileName + " opened.");

            while (fileReader.hasNextLine()) {
                String line = fileReader.nextLine();
                lineNumber++;

                Matcher m = fileContentPattern.matcher(line);
                boolean isMatching = m.matches();

                if (isMatching == false) {
                    System.out.println("Error! Wrong content!");
                    return false;
                }

                if (line.equals("")) {
                    System.out.format("Error! Line %d is empy!\n", lineNumber);
                    return false;
                }

                if (line.matches("^\\s+.*") || line.startsWith("0")) {
                    System.out.format("Error! Line %d starts with wrong symbol:%c\n", lineNumber, line.charAt(0));
                    return false;
                }

                String[] lineParts = line.split("\\s+");

                for (int i = 0; i < lineParts.length; i++) {
                    if (lineParts[i].startsWith("0")) {
                        System.out.format("Error! At line %d there is a wrong number starting with 0: %s\n", lineNumber,
                                lineParts[i]);
                        return false;
                    }
                }

                fileLines.add(line);
            }
        } catch (FileNotFoundException fnf) {
            System.out.println("File " + fileName + " not found.");
            return false;
        }

        System.out.println("Valid file name and content!");
        return true;
    }

    public ArrayList<String> getFileLines() {
        return fileLines;
    }

    public String getInputFile() {
        return inputFile;
    }

}