public class NumberAndSeparator {
    private String number;
    private String separator;

    public NumberAndSeparator(String number, String separator) {
        this.number = number;
        this.separator = separator;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getSeparator() {
        return separator;
    }

    public void setSeparator(String separator) {
        this.separator = separator;
    }
}
